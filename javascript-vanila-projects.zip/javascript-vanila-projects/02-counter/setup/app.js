const counter = 0;
const increaseBtn = document.getElementById("increase");
const decreaseBtn = document.getElementById("decrease");
const resetBtn = document.getElementById("resetBtn");
const value = document.getElementById("value")


const counterObj = new Counter(counter);
decreaseBtn.addEventListener("click", ()=>{ 
   console.log("decreaseBtn",counterObj.decrementCounter());
   value.textContent = counterObj.decrementCounter();
   value.style.color = "red";
});
increaseBtn.addEventListener("click", ()=>{ 
    console.log("increaseBtn", counterObj.incrementCounter() );
    value.textContent = counterObj.incrementCounter();
    value.style.color =  "green";
});
resetBtn.addEventListener("click", ()=>{ 
    console.log("resetBtn", counterObj.reset() );
    value.textContent = counterObj.reset();
    value.style.color =  "#000000";
});


function Counter(counter){
    this.counter = counter;
    this.incrementCounter =  () => {
           this.counter++;
           return this.counter;
    }

    this.decrementCounter = () => {
          this.counter--;
          return this.counter;
    }

    this.reset = () => {
        this.counter = 0;
        return this.counter;
    }
}